package com.example.qunltxe.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.qunltxe.Data_Models.Xe;

import java.util.ArrayList;

public class DBXe {
    DBHelper dbHelper;

    public DBXe(Context context) {
        dbHelper = new DBHelper(context);
    }

    public void Them(Xe xe) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("maxe", xe.getMaXe());
        values.put("tenxe", xe.getTenXe());
        values.put("dungtich", xe.getDungTich());
        values.put("soluong", xe.getSoLuong());
        values.put("maloai", xe.getMaLoai());
        db.insert("Xe", null, values);
    }

    public void Sua(Xe xe) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("maxe", xe.getMaXe());
        values.put("tenxe", xe.getTenXe());
        values.put("dungtich", xe.getDungTich());
        values.put("soluong", xe.getSoLuong());
        values.put("maloai", xe.getMaLoai());
        db.update("Xe", values, "maxe ='" + xe.getMaXe() + "'", null);
    }

    public void Xoa(Xe xe) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("Xe", "maxe ='" + xe.getMaXe() + "'", null);
    }

    public ArrayList<Xe> LayDL() {
        ArrayList<Xe> data = new ArrayList<>();
        String sql = "SELECT * FROM Xe";
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();

        try {
            cursor.moveToFirst();
            do {
                Xe xe = new Xe();
                xe.setMaXe(cursor.getString(0));
                xe.setTenXe(cursor.getString(1));
                xe.setDungTich(cursor.getInt(2));
                xe.setSoLuong(cursor.getInt(3));
                xe.setMaLoai(cursor.getString(4));
                data.add(xe);
            }
            while (cursor.moveToNext());
        } catch (Exception ex) {
        }


        return data;
    }

    public ArrayList<Xe> LayDL(String maxe) {
        ArrayList<Xe> data = new ArrayList<>();
        String sql = "SELECT * FROM Xe WHERE maxe ='" + maxe + "'";
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql, null);
        cursor.moveToFirst();

        try {
            cursor.moveToFirst();
            do {
                Xe xe = new Xe();
                xe.setMaXe(cursor.getString(0));
                xe.setTenXe(cursor.getString(1));
                xe.setDungTich(cursor.getInt(2));
                xe.setSoLuong(cursor.getInt(3));
                xe.setMaLoai(cursor.getString(4));
                data.add(xe);
            }
            while (cursor.moveToNext());
        } catch (Exception ex) {
        }

        return data;
    }
}
