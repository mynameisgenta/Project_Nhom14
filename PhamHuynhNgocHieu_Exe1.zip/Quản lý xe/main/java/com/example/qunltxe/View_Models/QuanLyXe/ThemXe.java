package com.example.qunltxe.View_Models.QuanLyXe;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.qunltxe.Data_Models.Xe;
import com.example.qunltxe.Database.DBXe;
import com.example.qunltxe.R;
import com.example.qunltxe.View_Models.HomePage.HomePage;

public class ThemXe extends AppCompatActivity {
    EditText txtMaxe, txtTenXe, txtDungTich, txtSoLuong, txtMaLoai;
    Button btnAdd, btnEdit, btnDelete, btnClear;
    ListView Lv_Xe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.them_xe);
        setControl();
        setEvent();
    }

    public Xe getXe() {
        Xe xe = new Xe();
        xe.setMaXe(txtMaxe.getText().toString());
        xe.setTenXe(txtTenXe.getText().toString());
        xe.setDungTich(Integer.parseInt(txtDungTich.getText().toString()));
        xe.setSoLuong(Integer.parseInt(txtSoLuong.getText().toString()));
        xe.setMaLoai(txtMaLoai.getText().toString());
        return xe;
    }

    public void setEvent() {
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputAdd();
            }
        });

        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtMaxe.setText("");
                txtTenXe.setText("");
                txtDungTich.setText("");
                txtSoLuong.setText("");
                txtMaLoai.setText("");
                AlertDialog.Builder alert = new AlertDialog.Builder(ThemXe.this);
                alert.setTitle("Thông báo");
                alert.setMessage("Clear thông tin xe thành công");
                alert.setPositiveButton("OK", null);
                alert.show();

            }
        });
    }

    public void setControl() {
        txtMaxe = findViewById(R.id.txtMaXe);
        txtTenXe = findViewById(R.id.txtTenXe);
        txtDungTich = findViewById(R.id.txtDungTich);
        txtSoLuong = findViewById(R.id.txtSoLuong);
        txtMaLoai = findViewById(R.id.txtMaLoai);
        btnAdd = findViewById(R.id.btnThem);
        btnClear = findViewById(R.id.btnClear);
        Lv_Xe = findViewById(R.id.lv_Xe);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actionbar, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int menuID = item.getItemId();
        switch (menuID) {
            case R.id.menuItemHome:
                home();
                break;

            case R.id.menuItemUpdate:
                checkList();
                break;

            default:
                Toast.makeText(this, "Có lỗi xảy ra !", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);
    }

    public void home() {
        new AlertDialog.Builder(ThemXe.this)
                .setMessage("Về trang chính ?")
                .setCancelable(false)
                .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ThemXe.this, HomePage.class);
                        startActivity(intent);
                    }
                })
                .setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                }).show();
    }

    public void checkList() {
        Intent intent = new Intent(this, DanhSachXe.class);
        startActivity(intent);
        Toast.makeText(this, "Cập nhật thành công !", Toast.LENGTH_SHORT).show();
    }

    public void InputAdd() {
        if (txtMaxe.getText().toString().isEmpty()) {
            txtMaxe.setError("Bạn chưa nhập mã xe");
        } else if (txtTenXe.getText().toString().isEmpty()) {
            txtTenXe.setError("Bạn chưa nhập tên xe");
        } else if (txtDungTich.getText().toString().isEmpty()) {
            txtDungTich.setError("Bạn chưa nhập dung tích xe");
        } else if (txtSoLuong.getText().toString().isEmpty()) {
            txtSoLuong.setError("Bạn chưa nhập số lượng xe");
        } else if (txtMaLoai.getText().toString().isEmpty()) {
            txtMaLoai.setError("Bạn chưa nhập mã loại xe");
        } else {
            DBXe dbXe = new DBXe(getApplicationContext());
            Xe xe = getXe();
            dbXe.Them(xe);
            AlertDialog.Builder alert = new AlertDialog.Builder(ThemXe.this);
            alert.setTitle("Thông báo");
            alert.setMessage("Thêm xe thành công");
            alert.setPositiveButton("OK", null);
            alert.show();
        }

    }
}