package com.example.qunltxe.Data_Models;

public class Xe {
    String MaXe;
    String TenXe;
    int DungTich;
    int SoLuong;
    String MaLoai;

    public Xe(String maXe, String tenXe, int dungTich, int soLuong, String maLoai) {
        MaXe = maXe;
        TenXe = tenXe;
        DungTich = dungTich;
        SoLuong = soLuong;
        MaLoai = maLoai;
    }

    public Xe() {

    }

    public String getMaXe() {
        return MaXe;
    }

    public void setMaXe(String maXe) {
        MaXe = maXe;
    }

    public String getTenXe() {
        return TenXe;
    }

    public void setTenXe(String tenXe) {
        TenXe = tenXe;
    }

    public int getDungTich() {
        return DungTich;
    }

    public void setDungTich(int dungTich) {
        DungTich = dungTich;
    }

    public int getSoLuong() {
        return SoLuong;
    }

    public void setSoLuong(int soLuong) {
        SoLuong = soLuong;
    }

    public String getMaLoai() {
        return MaLoai;
    }

    public void setMaLoai(String maLoai) {
        MaLoai = maLoai;
    }

    @Override
    public String toString() {
        return "Xe{" +
                "MaXe='" + MaXe + '\'' +
                ", TenXe='" + TenXe + '\'' +
                ", DungTich=" + DungTich +
                ", SoLuong=" + SoLuong +
                ", MaLoai='" + MaLoai + '\'' +
                '}';
    }
}
