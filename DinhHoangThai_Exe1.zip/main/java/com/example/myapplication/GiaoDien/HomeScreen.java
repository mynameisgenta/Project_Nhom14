package com.example.myapplication.GiaoDien;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Model.DanhSach;
import com.example.myapplication.R;

public class HomeScreen extends AppCompatActivity {
    Button btn_Qlcty, btn_Qlxe, btn_DHH, btn_Thoat, btn_Language;
    boolean language = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        requestWindowFeature(Window.FEATURE_NO_TITLE);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.home_screen);
        setControl();
        setEvent();
    }

    private void setEvent() {
        btn_Qlcty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeScreen.this, DanhSach.class);
                startActivity(intent);
            }
        });

        btn_Thoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(HomeScreen.this)
                        .setMessage("Bạn muốn thoát ?")
                        .setCancelable(false)
                        .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                finish();
                            }
                        })
                        .setNegativeButton("Không", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                // Perform Your Task Here--When No is pressed
                                dialog.cancel();
                            }
                        }).show();
            }
        });

        btn_Language.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (language)
                    btn_Language.setBackgroundResource(R.drawable.vn);
                else
                    btn_Language.setBackgroundResource(R.drawable.uk);
                language = !language;
            }
        });

    }

    public void setControl()
    {
        btn_Qlcty = findViewById(R.id.btn_Qlcty);
        btn_Qlxe = findViewById(R.id.btn_Qlxe);
        btn_DHH = findViewById(R.id.btn_DDH);
        btn_Thoat = findViewById(R.id.btn_Thoat);
        btn_Language = findViewById(R.id.btn_language);
    }
}
