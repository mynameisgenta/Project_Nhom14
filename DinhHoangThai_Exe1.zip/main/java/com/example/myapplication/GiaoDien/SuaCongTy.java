package com.example.myapplication.GiaoDien;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Database.DBCongTy;
import com.example.myapplication.Model.CongTy;
import com.example.myapplication.Model.DanhSach;
import com.example.myapplication.R;

import java.util.ArrayList;

public class SuaCongTy extends AppCompatActivity {
    EditText ed_maloai, ed_tenloai, ed_xuatxu;
    Button btn_sua, btn_clear;
    ArrayList<CongTy> dataCTY = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sua_cty);
        setControl();
        setEvent();
    }
    private CongTy getCongTy() {
        CongTy congTy = new CongTy();
        congTy.setMaLoai(ed_maloai.getText().toString());
        congTy.setTenLoai(ed_tenloai.getText().toString());
        congTy.setXuatXu(ed_xuatxu.getText().toString());
        return congTy;
    }

    private void setEvent() {
        String maloai = getIntent().getExtras().getString("maloai");
        DBCongTy dbCongTy = new DBCongTy(this);
        dataCTY = dbCongTy.LayDL(maloai);
        ed_maloai.setText(dataCTY.get(0).getMaLoai());
        ed_tenloai.setText(dataCTY.get(0).getTenLoai());
        ed_xuatxu.setText(dataCTY.get(0).getXuatXu());
        btn_sua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ed_tenloai.getText().toString().isEmpty()){
                    ed_tenloai.setError("Bạn chưa nhập tên loại");
                } else if (ed_xuatxu.getText().toString().isEmpty()) {
                    ed_xuatxu.setError("Bạn chưa nhập xuất xứ");
                } else {
                DBCongTy dbCongTy = new DBCongTy(getApplicationContext());
                CongTy congTy = getCongTy();
                dbCongTy.Sua(congTy);
                Toast.makeText(SuaCongTy.this, "Đã chỉnh sửa!", Toast.LENGTH_SHORT).show();
                }
//                ed_maloai.setText("");
//                ed_tenloai.setText("");
//                ed_xuatxu.setText("");
            }
        });


        btn_clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ed_tenloai.setText("");
                ed_xuatxu.setText("");
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_actionbar, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
//            case R.id.mnSave:
//                Log.d("test", "Lưu");
//                break;

            case R.id.mnopen:
                Log.d("test", "Mở");
                Intent intent = new Intent(this, DanhSach.class);
                startActivity(intent);
                break;

            case R.id.mnThoat:
                Log.d("test", "Home");
                Intent intent1 = new Intent(this, HomeScreen.class);
                startActivity(intent1);
                finish();
                break;
        }

        return super.onOptionsItemSelected(item);
    }
    private void setControl() {
        ed_maloai = findViewById(R.id.ed_maloai);
        ed_tenloai = findViewById(R.id.ed_tenloai);
        ed_xuatxu = findViewById(R.id.ed_xuatxu);
        btn_sua = findViewById(R.id.btn_sua);
        btn_clear = findViewById(R.id.btn_clear);
    }
}
