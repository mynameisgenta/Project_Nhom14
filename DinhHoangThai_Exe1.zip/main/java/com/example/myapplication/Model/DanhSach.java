package com.example.myapplication.Model;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.Adapter.CustomAdapter;
import com.example.myapplication.Database.DBCongTy;
import com.example.myapplication.GiaoDien.ThemCongTy;
import com.example.myapplication.R;

import java.util.ArrayList;

public class DanhSach extends AppCompatActivity {
    ListView lvCongty;
    ImageView img_add;
    ArrayList<CongTy> data_CTY = new ArrayList<>();
    CustomAdapter adapter_cty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_item);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        setControl();
        setEvent();
    }
    private void setEvent() {
        DBCongTy dbCongTy = new DBCongTy(this);
        data_CTY = dbCongTy.LayDL();

        CapnhapDL();

        img_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DanhSach.this, ThemCongTy.class);
                startActivity(intent);
            }
        });
    }

    private void setControl() {
        lvCongty = findViewById(R.id.lv_congty);
        img_add = findViewById(R.id.img_add);
    }

    public  void  CapnhapDL()
    {
        try {
            DBCongTy dbCongTy = new DBCongTy(this);
            adapter_cty = new CustomAdapter(this, R.layout.danh_sach_cty, dbCongTy.LayDL());
            lvCongty.setAdapter(adapter_cty);
        }
        catch (Exception ex)
        {
            lvCongty.setVisibility(View.GONE);
            Toast.makeText(this, "Không có dữ liệu", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView)myActionMenuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                if (TextUtils.isEmpty(s)){
                    adapter_cty.filter("");
                    lvCongty.clearTextFilter();
                }
                else {
                    adapter_cty.filter(s);
                }
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.mn_update:
                Toast.makeText(this, "Cập nhật", Toast.LENGTH_SHORT).show();
                break;
            case R.id.mn_delete:
                Toast.makeText(this, "Xóa", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onContextItemSelected(item);

    }
}
