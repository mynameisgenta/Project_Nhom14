package com.example.myapplication.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.myapplication.Model.CongTy;

import java.util.ArrayList;

public class DBCongTy {
    DBHelper dbHelper;

    public DBCongTy (Context context) {
        dbHelper= new DBHelper(context);
    }

    public void Them (CongTy congTy) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("maloai",congTy.getMaLoai());
        values.put("tenloai",congTy.getTenLoai());
        values.put("xuatxu",congTy.getXuatXu());

        db.insert("CongTy",null,values);
    }

    public  void Sua(CongTy congTy)
    {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("maloai",congTy.getMaLoai());
        values.put("tenloai",congTy.getTenLoai());
        values.put("xuatxu",congTy.getXuatXu());

        db.update("CongTy",values,"maloai ='"+congTy.getMaLoai() +"'",null);
    }

    public  void Xoa(CongTy congTy) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete("CongTy", "maloai ='" + congTy.getMaLoai() + "'", null);
    }

    public ArrayList<CongTy> LayDL()
    {
        ArrayList<CongTy> data = new ArrayList<>();
        String sql="select * from CongTy";
        SQLiteDatabase db= dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();

        try {
            cursor.moveToFirst();
            do {
                CongTy congTy = new CongTy();
                congTy.setMaLoai(cursor.getString(0));
                congTy.setTenLoai(cursor.getString(1));
                congTy.setXuatXu(cursor.getString(2));
                data.add(congTy);
            }
                while (cursor.moveToNext()) ;
        }
        catch (Exception ex){

            }
        return  data;
    }

    public ArrayList<CongTy> LayDL(String maloai)
    {
        ArrayList<CongTy> data = new ArrayList<>();
        String sql="select * from CongTy WHERE maloai = '"+ maloai + "'";
        SQLiteDatabase db= dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);
        cursor.moveToFirst();

        try {
            cursor.moveToFirst();
            do {
                CongTy congTy = new CongTy();
                congTy.setMaLoai(cursor.getString(0));
                congTy.setTenLoai(cursor.getString(1));
                congTy.setXuatXu(cursor.getString(2));
                data.add(congTy);
            }
            while (cursor.moveToNext()) ;
        }
        catch (Exception ex){

        }
        return  data;
    }
}
