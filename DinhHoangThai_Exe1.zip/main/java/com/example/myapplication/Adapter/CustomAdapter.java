package com.example.myapplication.Adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapplication.Database.DBCongTy;
import com.example.myapplication.Model.CongTy;
import com.example.myapplication.Model.DanhSach;
import com.example.myapplication.GiaoDien.SuaCongTy;
import com.example.myapplication.R;

import java.util.ArrayList;
import java.util.Locale;

public class CustomAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<CongTy> data;
    ArrayList<CongTy> data_CTY;

    public CustomAdapter(Context context, int resource, ArrayList<CongTy> data) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.data = data;
        this.data_CTY = new ArrayList<CongTy>();
        this.data_CTY.addAll(data);
}

    @Override
    public int getCount() {
        return data.size();
    }

    private static class Holder{
        TextView tv_maloai;
        TextView tv_tenloai;
        TextView tv_xuatxu;
        ImageView img_delete;
        ImageView img_edit;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view =convertView;
        Holder holder = null;
        if(view == null) {
            holder = new Holder();
            view = LayoutInflater.from(context).inflate(resource, null);
            holder.tv_maloai = view.findViewById(R.id.tv_maloai);
            holder.tv_tenloai = view.findViewById(R.id.tv_tenloai);
            holder.tv_xuatxu = view.findViewById(R.id.tv_xuatxu);
            holder.img_delete = view.findViewById(R.id.img_delete);
            holder.img_edit = view.findViewById(R.id.img_edit);

            view.setTag(holder);
        }
        else
            holder=(Holder)view.getTag();

        final CongTy congTy = data.get(position);
        holder.tv_maloai.setText(congTy.getMaLoai());
        holder.tv_tenloai.setText(congTy.getTenLoai());
        holder.tv_xuatxu.setText(congTy.getXuatXu());
        holder.img_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getContext())
                        .setMessage("Bạn có chắc muốn xóa?")
                        .setCancelable(false)
                        .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                DBCongTy dbCongTy = new DBCongTy(context);
                                dbCongTy.Xoa(congTy);

                                DanhSach danhSach = (DanhSach)context;
                                danhSach.CapnhapDL();
                            }
                        })
                        .setNegativeButton("Không", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                dialogInterface.cancel();
                            }
                        }).show();
            }
        });

        holder.img_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, SuaCongTy.class);
                Bundle bundle = new Bundle();
                bundle.putString("maloai",congTy.getMaLoai());
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });

        return view;
    }

    //filter
    public void filter(String charText){
        charText = charText.toLowerCase(Locale.getDefault());
        data.clear();
        if (charText.length()==0){
            data.addAll(data_CTY);
        }
        else {
            for (CongTy model : data_CTY){
                if (model.getMaLoai().toLowerCase(Locale.getDefault())
                        .contains(charText)  ){
                    data.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }
}
