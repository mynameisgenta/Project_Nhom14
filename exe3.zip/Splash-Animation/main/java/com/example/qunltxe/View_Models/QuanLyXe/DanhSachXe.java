package com.example.qunltxe.View_Models.QuanLyXe;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.qunltxe.Adapter.XeAdapter;
import com.example.qunltxe.Data_Models.Xe;
import com.example.qunltxe.Database.DBXe;
import com.example.qunltxe.R;

import java.util.ArrayList;

public class DanhSachXe extends AppCompatActivity {
    ListView Lv_xe;
    ImageView img_add;
    ArrayList<Xe> data_XE = new ArrayList<>();
    XeAdapter adapter_xe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_item);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        setControl();
        setEvent();
    }

    private void setEvent() {
        DBXe dbXe = new DBXe(this);
        data_XE = dbXe.LayDL();
        CapnhatDL();

        img_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DanhSachXe.this, ThemXe.class);
                startActivity(intent);
            }
        });
    }

    private void setControl() {
        Lv_xe = findViewById(R.id.lv_Xe);
        img_add = findViewById(R.id.img_add);
    }

    public void CapnhatDL() {
        try {
            DBXe dbXe = new DBXe(this);
            adapter_xe = new XeAdapter(this, R.layout.danh_sach_xe, dbXe.LayDL());
            Lv_xe.setAdapter(adapter_xe);
        } catch (Exception ex) {
            Lv_xe.setVisibility(View.GONE);
            AlertDialog.Builder alert = new AlertDialog.Builder(DanhSachXe.this);
            alert.setTitle("Thông báo");
            alert.setMessage("Bạn chưa thêm dữ liệu xe nào ! ");
            alert.setPositiveButton("OK", null);
            alert.show();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        MenuItem myActionMenuItem = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) myActionMenuItem.getActionView();
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                if (TextUtils.isEmpty(s)) {
                    adapter_xe.filter("");
                    Lv_xe.clearTextFilter();
                } else {
                    adapter_xe.filter(s);
                }
                return true;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case R.id.mn_update:
                Toast.makeText(this, "Cập nhật", Toast.LENGTH_SHORT).show();
                break;
            case R.id.mn_delete:
                Toast.makeText(this, "Xóa", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onContextItemSelected(item);

    }
}

