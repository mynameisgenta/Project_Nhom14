package com.example.qunltxe.View_Models.HomePage;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.qunltxe.R;
import com.example.qunltxe.View_Models.QuanLyXe.DanhSachXe;

public class HomePage extends AppCompatActivity {
    Button btnQuanLyCty, btnQuanLyXe, btnDonDatHang, btnExit, btnLanguage;
    Boolean language = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.homepage);
        setControl();
        setEvent();
    }


    private void setEvent() {

        btnLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (language) {
                    btnLanguage.setBackgroundResource(R.mipmap.vietnam);
                } else {
                    btnLanguage.setBackgroundResource(R.mipmap.uk);
                }

                language = !language;
            }
        });

        btnQuanLyXe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomePage.this, DanhSachXe.class);
                startActivity(intent);
            }
        });

        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(HomePage.this)
                        .setMessage("Bạn muốn thoát ?")
                        .setCancelable(false)
                        .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        })
                        .setNegativeButton("Không", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                // Perform Your Task Here--When No is pressed
                                dialog.cancel();
                            }
                        }).show();
            }
        });

    }

    public void setControl() {
        btnQuanLyCty = findViewById(R.id.btnQuanLyCty);
        btnQuanLyXe = findViewById(R.id.btnQuanLyXe);
        btnDonDatHang = findViewById(R.id.btnDonDatHang);
        btnExit = findViewById(R.id.btnExit);
        btnLanguage = findViewById(R.id.btnLanguage);
    }
}