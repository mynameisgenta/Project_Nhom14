package com.example.qunltxe.View_Models.HomePage;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

import com.example.qunltxe.R;

public class FingerLogin extends AppCompatActivity {
    ImageButton finger_login;
    LinearLayout screen1;
    Handler handler = new Handler();
    Runnable runnable = new Runnable() {
        @Override
        public void run() {
            screen1.setVisibility(View.VISIBLE);
        }
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.finger_login);
        setControl();
        setEvent();
    }

    private void setEvent() {
        handler.postDelayed(runnable, 2000);
    }

    private void setControl() {
        finger_login = findViewById(R.id.finger_login);
        screen1 = findViewById(R.id.screen1);
    }
}