package com.example.qunltxe.Adapter;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.example.qunltxe.Data_Models.Xe;
import com.example.qunltxe.Database.DBXe;
import com.example.qunltxe.R;
import com.example.qunltxe.View_Models.QuanLyXe.ChinhSuaXe;
import com.example.qunltxe.View_Models.QuanLyXe.DanhSachXe;

import java.util.ArrayList;
import java.util.Locale;

public class XeAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<Xe> data;
    ArrayList<Xe> data_XE;

    public XeAdapter(Context context, int resource, ArrayList<Xe> data) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.data = data;
        this.data_XE = new ArrayList<Xe>();
        this.data_XE.addAll(data);
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        Holder holder = null;
        if (view == null) {
            holder = new Holder();
            view = LayoutInflater.from(context).inflate(resource, null);
            holder.img_xe = view.findViewById(R.id.img_xe);
            holder.img_delete = view.findViewById(R.id.img_delete);
            holder.img_edit = view.findViewById(R.id.img_edit);
            holder.tvMaxe = view.findViewById(R.id.tvMaxe);
            holder.tvTenxe = view.findViewById(R.id.tvTenxe);
            holder.tvDungtich = view.findViewById(R.id.tvDungtich);
            holder.tvSoluong = view.findViewById(R.id.tvSoluong);
            holder.tvMaloai = view.findViewById(R.id.tvMaloai);
            view.setTag(holder);
        } else {
            holder = (Holder) view.getTag();
        }

        final Xe xe = data.get(position);
        holder.tvMaxe.setText(xe.getMaXe());
        holder.tvTenxe.setText(xe.getTenXe());
        holder.tvDungtich.setText(String.valueOf(xe.getDungTich()));
        holder.tvSoluong.setText(String.valueOf(xe.getSoLuong()));
        holder.tvMaloai.setText(xe.getMaLoai());
        holder.img_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getContext())
                        .setMessage("Bạn muốn xóa xe " + xe.getTenXe() + " ?")
                        .setCancelable(false)
                        .setPositiveButton("Có", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                DBXe dbXe = new DBXe(context);
                                dbXe.Xoa(xe);
                                Toast.makeText(getContext(), "Xóa thành công !", Toast.LENGTH_SHORT).show();
                                DanhSachXe danhSach = (DanhSachXe) context;
                                danhSach.CapnhatDL();
                            }
                        })
                        .setNegativeButton("Không", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        }).show();
            }
        });

        holder.img_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ChinhSuaXe.class);
                Bundle bundle = new Bundle();
                bundle.putString("maxe", xe.getMaXe());
                intent.putExtras(bundle);
                context.startActivity(intent);
            }
        });


        return view;
    }

    //filter
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        data.clear();
        if (charText.length() == 0) {
            data.addAll(data_XE);
        } else {
            for (Xe model : data_XE) {
                if (model.getMaXe().toLowerCase(Locale.getDefault())
                        .contains(charText)) {
                    data.add(model);
                }
            }
        }
        notifyDataSetChanged();
    }

    private static class Holder {
        TextView tvMaxe;
        TextView tvTenxe;
        TextView tvDungtich;
        TextView tvSoluong;
        TextView tvMaloai;
        ImageView img_delete;
        ImageView img_xe;
        ImageView img_edit;
    }
}
